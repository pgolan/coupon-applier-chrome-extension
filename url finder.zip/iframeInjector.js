	var iframe  = document.createElement ("iframe");
	iframe.src  = chrome.extension.getURL ("test.html");

	//var yourDIV = document.getElementById("actPanel  vi-noborder ");
	//var yourDIV = document.getElementById("openModal");
	var mybod=document.getElementsByTagName('body')[0];

	mybod.appendChild(iframe);
	iframe.width="700px";
	iframe.height="200px";

	document.body.insertBefore(iframe, document.body.firstChild);
//yourDIV.appendChild(iframe);

	var btn = document.createElement("BUTTON")
    var t = document.createTextNode("best Coupon Finder In the Whole Country ! ");
    btn.appendChild(t);
    //Appending to DOM 
    document.body.appendChild(btn);
    document.body.insertBefore(btn, document.body.firstChild);

   var mydiv=document.getElementById("why2buy");
    var btn2 = document.createElement("BUTTON")
    btn2.name="modopen()";
    btn2.onclick="mod()";
    var t2 = document.createTextNode("coupon finder !! ");
    btn2.appendChild(t2);
    //Appending to DOM 
    mydiv.appendChild(btn2);

    var mya=document.createElement("a");
    //a.href="#";
    mydiv.appendChild(mya);

    var myimg=document.createElement("img");
    myimg.src=chrome.extension.getURL("project.png");
    //mya.appendChild(myimg);
    mydiv.appendChild(myimg);






